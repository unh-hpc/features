### ADIOS2 queryWorker example

The _queryWorker_ example demonstrates how to read variables using ADIOS2's BP engine
and perform queries on the read data and streams the results.

1. q1.json is a json query file for one var

2. q2.json is a composite query

3. The bp*xml are the from heat transfer example with bp4 engine, and <adios-query> tag is added at the end for xml
   query spec
