
module Helper

include("helperMPI.jl")
include("helperString.jl")

end