#include <stdbool.h>
#include <rdma/fabric.h>
#include <rdma/fi_cxi_ext.h>

int main() {}
