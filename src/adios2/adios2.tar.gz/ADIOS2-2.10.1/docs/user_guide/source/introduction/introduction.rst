############
Introduction
############

.. include:: nutshell.rst
.. include:: adaptable_io.rst
