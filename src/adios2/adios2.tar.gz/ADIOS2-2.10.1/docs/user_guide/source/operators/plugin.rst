***************
Plugin Operator
***************

For details on using the Plugin Operator, see the :ref:`Plugins` documentation.

