############################
HDF5 API Support through VOL
############################

We have developed a HDF5 VOL in order to comply with the ECP request to support HDF5 API. Through this VOL the HDF5 clients can read and write general ADIOS files. 

.. include:: h5vol/vol.rst
