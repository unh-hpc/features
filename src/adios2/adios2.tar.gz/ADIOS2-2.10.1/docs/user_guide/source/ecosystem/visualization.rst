################
Visualizing Data
################

Certain ADIOS2 bp files can be recognized by third party visualization tools.
This section describes how to create an ADIOS2 bp file to accomodate the visualization product requirements.

.. include:: visualization/vtk.rst
