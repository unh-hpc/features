*************
Plugin Engine
*************

For details on using the Plugin Engine, see the :ref:`Plugins` documentation.
