#ifndef ADIOS2_BINDINGS_CXX11_CXX11_ADIOS_VIEW_H_
#define ADIOS2_BINDINGS_CXX11_CXX11_ADIOS_VIEW_H_

namespace adios2
{
template <typename T, class... Parameters>
class AdiosView
{
public:
    AdiosView() = delete;
};
}

#endif /* ADIOS2_BINDINGS_CXX11_CXX11_ADIOS_VIEW_H_ */
